📄 تعليمات تشغيل GoldenBot Lite:

1. ثبت المكتبات:
   pip install -r requirements.txt

2. ضع التوكن في ملف config.json
   TOKEN = توكن البوت
   CHAT_ID = رقم معرف القناة (مثلاً: -1001234567890)

3. شغل البوت:
   python goldenbot.py

✔️ سيقوم البوت كل ساعة بتحليل سعر الذهب وإرسال صفقة محتملة.