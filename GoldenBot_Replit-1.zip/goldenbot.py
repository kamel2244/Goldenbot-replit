
import json
import time
import requests
import yfinance as yf
from telegram import Bot

# تحميل الإعدادات
with open("config.json", "r") as f:
    config = json.load(f)

TOKEN = config["TOKEN"]
CHAT_ID = config["CHAT_ID"]

bot = Bot(token=TOKEN)

def fetch_gold_price():
    data = yf.download("XAUUSD=X", period="1d", interval="15m")
    if data.empty:
        return None
    close = data["Close"]
    last_price = close.iloc[-1]
    prev_price = close.iloc[-2]
    return last_price, prev_price

def generate_signal(price, prev_price):
    if price > prev_price * 1.002:
        return f"💰 صفقة شراء:
📈 دخول: {prev_price:.2f}
🎯 هدف: {price + 5:.2f}
🛑 وقف خسارة: {price - 3:.2f}"
    elif price < prev_price * 0.998:
        return f"💰 صفقة بيع:
📉 دخول: {prev_price:.2f}
🎯 هدف: {price - 5:.2f}
🛑 وقف خسارة: {price + 3:.2f}"
    return None

def main():
    while True:
        try:
            price_data = fetch_gold_price()
            if price_data:
                price, prev_price = price_data
                signal = generate_signal(price, prev_price)
                if signal:
                    bot.send_message(chat_id=CHAT_ID, text=signal)
            time.sleep(3600)  # ساعة
        except Exception as e:
            bot.send_message(chat_id=CHAT_ID, text=f"❌ خطأ في البوت: {e}")
            time.sleep(600)

if __name__ == "__main__":
    main()
